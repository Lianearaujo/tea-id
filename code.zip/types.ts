
export type ProfileType = 'responsavel' | 'profissional' | 'admin';

export interface User {
  id: string;
  name?: string;
  email: string;
  profileType: ProfileType;
}

export type TherapyType = 'Fonoaudiologia' | 'Psicologia (ABA)' | 'Terapia Ocupacional' | 'Psicopedagogia';

export interface Session {
  id: string;
  date: string;
  therapist: string;
  therapyType: TherapyType;
  notes: string;
  audioUrl?: string;
  aiFeedback?: string;
}

export interface Patient {
    id: string;
    name: string;
    birthDate: string;
    diagnosis: string;
    avatarUrl: string;
}
