
import React, { useState } from 'react';
import LoginPage from './components/pages/LoginPage.tsx';
import RegisterPage from './components/pages/RegisterPage.tsx';
import DashboardPage from './components/pages/DashboardPage.tsx';
import { useAuth } from './hooks/useAuth.ts';
import type { User } from './types.ts';

type Page = 'login' | 'register';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authPage, setAuthPage] = useState<Page>('login');
  const { logout } = useAuth();

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setAuthPage('login');
  };

  const navigateToRegister = () => setAuthPage('register');
  const navigateToLogin = () => setAuthPage('login');

  if (user) {
    return <DashboardPage user={user} onLogout={handleLogout} />;
  }

  return (
    <main>
      {authPage === 'login' && <LoginPage onLoginSuccess={handleLoginSuccess} onNavigateToRegister={navigateToRegister} />}
      {authPage === 'register' && <RegisterPage onNavigateToLogin={navigateToLogin} />}
    </main>
  );
}

export default App;
