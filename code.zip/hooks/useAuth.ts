
import { useState } from 'react';
import type { ProfileType, User } from '../types.ts';

export function useAuth() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const login = async (email: string, password: string, profileType: ProfileType): Promise<User | null> => {
    setLoading(true);
    setError(null);

    console.log(`Attempting to log in as ${profileType} with email: ${email}`);
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
      // Mock admin login
      if (email.toLowerCase() === 'admin@admin.com' && password === 'admin') {
        console.log("Admin login successful");
        setLoading(false);
        return {
          id: 'admin-user-01',
          email: 'admin@admin.com',
          name: 'Admin',
          profileType: 'admin',
        };
      }

      // ** FIREBASE LOGIN INTEGRATION POINT **
      // import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
      // const auth = getAuth();
      // const userCredential = await signInWithEmailAndPassword(auth, email, password);
      // const firebaseUser = userCredential.user;
      // Then, fetch user profile from Firestore to verify profileType and get full user data.
      // const userDoc = await getDoc(doc(db, "users", firebaseUser.uid));
      // if (userDoc.exists() && userDoc.data().profileType === profileType) {
      //   return { id: firebaseUser.uid, ...userDoc.data() } as User;
      // } else {
      //   // Sign out if profile type doesn't match
      //   await auth.signOut();
      //   throw new Error("Tipo de perfil não corresponde ao selecionado.");
      // }

      if (email === "error@example.com") {
        throw new Error("Credenciais inválidas. Verifique seu e-mail e senha.");
      }
      
      // For non-admin demo users, simulate failure
      throw new Error("Credenciais inválidas. Use admin@admin.com para acessar.");

    } catch (err) {
      console.error("Login failed:", err);
      const errorMessage = err instanceof Error ? err.message : "Ocorreu um erro inesperado.";
      setError(errorMessage);
      setLoading(false);
      return null;
    }
  };

  const register = async (name: string, email: string, password: string, profileType: ProfileType) => {
    setLoading(true);
    setError(null);

    console.log(`Attempting to register ${name} as ${profileType} with email: ${email}`);
    await new Promise(resolve => setTimeout(resolve, 1500));

    try {
        // ** FIREBASE REGISTER INTEGRATION POINT **
        // import { getAuth, createUserWithEmailAndPassword } from "firebase/auth";
        // import { getFirestore, doc, setDoc } from "firebase/firestore";
        //
        // const auth = getAuth();
        // const db = getFirestore();
        //
        // const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        // const user = userCredential.user;
        //
        // // Store additional user info in Firestore
        // await setDoc(doc(db, "users", user.uid), {
        //   name: name,
        //   email: email,
        //   profileType: profileType,
        //   createdAt: new Date()
        // });

        if (email === "exists@example.com") {
            throw new Error("Este e-mail já está em uso.");
        }

        console.log("Registration successful (simulated)");
        setLoading(false);
        return true;

    } catch (err) {
        console.error("Registration failed (simulated):", err);
        const errorMessage = err instanceof Error ? err.message : "Ocorreu um erro inesperado durante o cadastro.";
        setError(errorMessage);
        setLoading(false);
        return false;
    }
  };
  
  const logout = async (): Promise<void> => {
    // ** FIREBASE LOGOUT INTEGRATION POINT **
    // import { getAuth } from "firebase/auth";
    // const auth = getAuth();
    // await auth.signOut();
    console.log("User logged out");
  };

  return { login, register, logout, loading, error };
}
