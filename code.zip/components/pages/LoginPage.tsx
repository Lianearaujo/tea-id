
import React, { useState, FormEvent } from 'react';
import type { ProfileType, User } from '../../types.ts';
import { useAuth } from '../../hooks/useAuth.ts';
import Card from '../ui/Card.tsx';
import Input from '../ui/Input.tsx';
import Button from '../ui/Button.tsx';
import LogoIcon from '../icons/LogoIcon.tsx';
import AtSymbolIcon from '../icons/AtSymbolIcon.tsx';
import LockIcon from '../icons/LockIcon.tsx';

interface LoginPageProps {
  onNavigateToRegister: () => void;
  onLoginSuccess: (user: User) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onNavigateToRegister, onLoginSuccess }) => {
  const [activeProfile, setActiveProfile] = useState<ProfileType>('profissional');
  const [email, setEmail] = useState('admin@admin.com');
  const [password, setPassword] = useState('admin');
  const { login, loading, error } = useAuth();

  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    const user = await login(email, password, activeProfile);
    if (user) {
      onLoginSuccess(user);
    }
  };

  const ProfileSelector: React.FC = () => (
    <div className="grid grid-cols-2 gap-2 mb-6 bg-slate-100 p-1 rounded-lg">
      <button
        type="button"
        onClick={() => setActiveProfile('responsavel')}
        aria-pressed={activeProfile === 'responsavel'}
        className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
          activeProfile === 'responsavel'
            ? 'bg-white text-indigo-600 shadow-sm'
            : 'bg-transparent text-slate-600 hover:bg-slate-200'
        }`}
      >
        Responsável
      </button>
      <button
        type="button"
        onClick={() => setActiveProfile('profissional')}
        aria-pressed={activeProfile === 'profissional'}
        className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${
          activeProfile === 'profissional'
            ? 'bg-white text-indigo-600 shadow-sm'
            : 'bg-transparent text-slate-600 hover:bg-slate-200'
        }`}
      >
        Profissional
      </button>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 via-white to-cyan-50 p-4">
      <Card>
        <div className="text-center mb-8">
          <LogoIcon className="mx-auto h-16 w-auto text-indigo-600" />
          <h1 className="mt-4 text-2xl font-bold tracking-tight text-slate-800 sm:text-3xl">
            Bem-vindo ao TEA ID
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            Acesse sua conta para continuar
          </p>
        </div>

        <ProfileSelector />

        <form onSubmit={handleLogin} className="space-y-6">
          <Input
            id="email"
            type="email"
            label="E-mail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
            icon={<AtSymbolIcon />}
          />
          <Input
            id="password"
            type="password"
            label="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            icon={<LockIcon />}
          />

          <div className="text-right text-sm">
            <a href="#" className="font-medium text-indigo-600 hover:text-indigo-500">
              Esqueceu sua senha?
            </a>
          </div>

          {error && (
            <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded-md text-sm" role="alert">
              <p>{error}</p>
            </div>
          )}

          <Button type="submit" loading={loading} fullWidth>
            Entrar
          </Button>

          <p className="mt-8 text-center text-sm text-slate-600">
            Não tem uma conta?{' '}
            <button type="button" onClick={onNavigateToRegister} className="font-medium text-indigo-600 hover:text-indigo-500 focus:outline-none">
              Cadastre-se
            </button>
          </p>
        </form>
      </Card>
    </div>
  );
};

export default LoginPage;
